# AI Gold — Equiti MT5 / XAUUSD.sd

## What this is
A two-part starter system:
1. `AI_Gold_Equiti.mq5` — MT5 EA for XAUUSD.sd.
2. `ai_service.py` + `train_model.py` — local machine-learning service.

The EA sends measurable market features to the local AI service. The model returns BUY, SELL or NO_TRADE plus confidence.

## Important limitation
The system cannot directly see the secret positions of all whales or market makers in spot XAUUSD. It uses observable proxies such as liquidity sweeps, market structure and volatility. For stronger institutional-flow signals, add futures/order-flow data later.

## Setup
1. Install Python 3.10+.
2. In a terminal:
   `pip install fastapi uvicorn pandas numpy scikit-learn joblib`
3. Obtain historical M5 data for the exact Equiti symbol `XAUUSD.sd` and save it as CSV with:
   `time,open,high,low,close,volume`
4. Train:
   `python train_model.py --csv xauusd_m5.csv --out model.joblib`
5. Start AI:
   `uvicorn ai_service:app --host 127.0.0.1 --port 8000`
6. In MT5: Tools > Options > Expert Advisors > enable WebRequest for:
   `http://127.0.0.1:8000`
7. Compile `AI_Gold_Equiti.mq5` in MetaEditor and attach it to `XAUUSD.sd`, preferably M5.
8. Keep `AllowTrading=false` until the model passes out-of-sample and demo forward testing.

## Safety
This is research software, not a guaranteed profitable system. The default is signal-only. Do not enable live trading until you have independently validated the model on unseen data and demo trading.
