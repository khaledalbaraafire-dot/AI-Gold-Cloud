# AI Gold Liquidity Service
# Python 3.10+
#
# This is a REAL ML inference service, but the model must be trained on
# historical XAUUSD data before live use. It deliberately refuses to
# pretend that it knows the true positions of whales/market makers.
#
# Install:
#   pip install fastapi uvicorn pandas numpy scikit-learn joblib
#
# Start:
#   uvicorn ai_service:app --host 127.0.0.1 --port 8000
#
# Train:
#   python train_model.py --csv xauusd_m5.csv --out model.joblib

from pathlib import Path
import json
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
import joblib

MODEL_PATH = Path("model.joblib")
app = FastAPI(title="AI Gold Liquidity Service")
model = None

FEATURES = [
    "ret1", "body", "range", "ema_gap", "trend",
    "buy_sweep", "sell_sweep", "spread_points"
]

class TickFeatures(BaseModel):
    symbol: str
    timeframe: str
    close: float
    ret1: float
    body: float
    range: float
    ema_gap: float
    trend: float
    buy_sweep: float
    sell_sweep: float
    atr: float
    spread_points: float

@app.on_event("startup")
def load_model():
    global model
    if MODEL_PATH.exists():
        model = joblib.load(MODEL_PATH)

@app.get("/health")
def health():
    return {"ok": True, "model_loaded": model is not None}

@app.post("/predict")
def predict(x: TickFeatures):
    if model is None:
        return {"signal":"NO_TRADE","confidence":0.0,
                "sl_distance":x.atr*1.5,
                "reason":"Model not trained. Train model.joblib first."}

    X = np.array([[getattr(x, f) for f in FEATURES]], dtype=float)
    probs = model.predict_proba(X)[0]
    classes = list(model.classes_)
    # Class 1 = bullish, 0 = bearish in the training script.
    p_up = float(probs[classes.index(1)])
    p_down = float(probs[classes.index(0)])

    # Conservative threshold: otherwise no trade.
    if p_up >= 0.72 and p_up > p_down:
        signal = "BUY"
        confidence = p_up
        reason = "ML probability favors bullish continuation/reversal setup."
    elif p_down >= 0.72 and p_down > p_up:
        signal = "SELL"
        confidence = p_down
        reason = "ML probability favors bearish continuation/reversal setup."
    else:
        signal = "NO_TRADE"
        confidence = max(p_up, p_down)
        reason = "Model confidence below trade threshold."

    sl_distance = max(x.atr * 1.5, 0.5)
    return {"signal":signal, "confidence":confidence,
            "sl_distance":sl_distance, "reason":reason}
