//+------------------------------------------------------------------+
//| AI_Gold_Equiti.mq5                                               |
//| XAUUSD.sd - AI + Liquidity/Whale inference EA                   |
//| NOTE: AI inference is performed by the local Python service.     |
//+------------------------------------------------------------------+
#property strict
#property version "1.00"

#include <Trade/Trade.mqh>
CTrade trade;

input string InpSymbol              = "XAUUSD.sd";
input ENUM_TIMEFRAMES InpTF         = PERIOD_M5;
input string InpAIUrl               = "http://127.0.0.1:8000/predict";
input double MinConfidence          = 0.72;
input double RiskPercent            = 0.50;
input double SL_ATR_Mult            = 1.50;
input double TP1_R                  = 1.20;
input double TP2_R                  = 2.00;
input int    ATR_Period             = 14;
input int    EMA_Fast               = 20;
input int    EMA_Slow               = 50;
input int    LookbackLiquidity      = 20;
input int    MaxSpreadPoints        = 80;
input bool   AllowTrading           = false; // SAFE DEFAULT: signals only

datetime last_bar = 0;

double GetATR()
{
   int h=iATR(InpSymbol,InpTF,ATR_Period);
   if(h==INVALID_HANDLE) return 0;
   double b[];
   ArraySetAsSeries(b,true);
   if(CopyBuffer(h,0,1,1,b)!=1) { IndicatorRelease(h); return 0; }
   double v=b[0];
   IndicatorRelease(h);
   return v;
}

double GetEMA(int period,int shift=1)
{
   int h=iMA(InpSymbol,InpTF,period,0,MODE_EMA,PRICE_CLOSE);
   if(h==INVALID_HANDLE) return 0;
   double b[];
   ArraySetAsSeries(b,true);
   if(CopyBuffer(h,0,shift,1,b)!=1) { IndicatorRelease(h); return 0; }
   double v=b[0];
   IndicatorRelease(h);
   return v;
}

bool NewBar()
{
   datetime t=iTime(InpSymbol,InpTF,0);
   if(t==0 || t==last_bar) return false;
   last_bar=t;
   return true;
}

string JsonEscape(string s)
{
   StringReplace(s,"\\","\\\\");
   StringReplace(s,"\"","\\\"");
   return s;
}

bool PostAI(string payload,string &response)
{
   char data[], result[];
   string headers="Content-Type: application/json\r\n";
   StringToCharArray(payload,data,0,WHOLE_ARRAY,CP_UTF8);
   ResetLastError();
   int code=WebRequest("POST",InpAIUrl,headers,5000,data,result,headers);
   if(code==-1)
   {
      Print("WebRequest failed. Add http://127.0.0.1:8000 to MT5: Tools > Options > Expert Advisors > Allow WebRequest.");
      return false;
   }
   response=CharArrayToString(result,0,-1,CP_UTF8);
   return (code>=200 && code<300);
}

double HighestHigh(int n)
{
   double hh=-DBL_MAX;
   for(int i=2;i<2+n;i++) hh=MathMax(hh,iHigh(InpSymbol,InpTF,i));
   return hh;
}

double LowestLow(int n)
{
   double ll=DBL_MAX;
   for(int i=2;i<2+n;i++) ll=MathMin(ll,iLow(InpSymbol,InpTF,i));
   return ll;
}

double PositionSize(double stop_distance)
{
   if(stop_distance<=0) return 0.01;
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double risk_money=equity*RiskPercent/100.0;
   double tick_value=SymbolInfoDouble(InpSymbol,SYMBOL_TRADE_TICK_VALUE);
   double tick_size=SymbolInfoDouble(InpSymbol,SYMBOL_TRADE_TICK_SIZE);
   double vol_min=SymbolInfoDouble(InpSymbol,SYMBOL_VOLUME_MIN);
   double vol_max=SymbolInfoDouble(InpSymbol,SYMBOL_VOLUME_MAX);
   double vol_step=SymbolInfoDouble(InpSymbol,SYMBOL_VOLUME_STEP);
   if(tick_value<=0 || tick_size<=0) return vol_min;
   double money_per_lot=(stop_distance/tick_size)*tick_value;
   double lots=risk_money/money_per_lot;
   lots=MathFloor(lots/vol_step)*vol_step;
   lots=MathMax(vol_min,MathMin(vol_max,lots));
   return NormalizeDouble(lots,2);
}

void OnTick()
{
   if(!NewBar()) return;

   MqlTick tick;
   if(!SymbolInfoTick(InpSymbol,tick)) return;
   double point=SymbolInfoDouble(InpSymbol,SYMBOL_POINT);
   double spread_points=(tick.ask-tick.bid)/point;
   if(spread_points>MaxSpreadPoints)
   {
      Comment("AI GOLD: NO TRADE | Spread too high: ",DoubleToString(spread_points,1));
      return;
   }

   double atr=GetATR();
   double ema20=GetEMA(EMA_Fast,1);
   double ema50=GetEMA(EMA_Slow,1);
   if(atr<=0 || ema20<=0 || ema50<=0) return;

   double c1=iClose(InpSymbol,InpTF,1);
   double o1=iOpen(InpSymbol,InpTF,1);
   double h1=iHigh(InpSymbol,InpTF,1);
   double l1=iLow(InpSymbol,InpTF,1);
   double c2=iClose(InpSymbol,InpTF,2);

   double hh=HighestHigh(LookbackLiquidity);
   double ll=LowestLow(LookbackLiquidity);

   // Liquidity sweep proxies:
   double buy_side_sweep  = (h1>hh && c1<hh) ? 1.0 : 0.0;
   double sell_side_sweep = (l1<ll && c1>ll) ? 1.0 : 0.0;

   // Normalized features sent to AI.
   double ret1=(c1-c2)/atr;
   double body=(c1-o1)/atr;
   double range=(h1-l1)/atr;
   double ema_gap=(c1-ema50)/atr;
   double trend=(ema20-ema50)/atr;

   string payload=StringFormat(
      "{\"symbol\":\"%s\",\"timeframe\":\"M5\",\"close\":%.5f,"
      "\"ret1\":%.6f,\"body\":%.6f,\"range\":%.6f,\"ema_gap\":%.6f,"
      "\"trend\":%.6f,\"buy_sweep\":%.0f,\"sell_sweep\":%.0f,"
      "\"atr\":%.6f,\"spread_points\":%.1f}",
      JsonEscape(InpSymbol),c1,ret1,body,range,ema_gap,trend,
      buy_side_sweep,sell_side_sweep,atr,spread_points);

   string response="";
   if(!PostAI(payload,response))
   {
      Comment("AI GOLD: AI service unavailable");
      return;
   }

   // Expected response:
   // {"signal":"BUY","confidence":0.81,"sl_distance":6.2,"reason":"..."}
   string signal="";
   double conf=0, sl_dist=0;

   int p=StringFind(response,"\"signal\":\"");
   if(p>=0)
   {
      int s=p+10, e=StringFind(response,"\"",s);
      if(e>s) signal=StringSubstr(response,s,e-s);
   }
   p=StringFind(response,"\"confidence\":");
   if(p>=0) conf=StringToDouble(StringSubstr(response,p+13));
   p=StringFind(response,"\"sl_distance\":");
   if(p>=0) sl_dist=StringToDouble(StringSubstr(response,p+14));

   if(sl_dist<=0) sl_dist=atr*SL_ATR_Mult;

   Comment("AI GOLD | ",signal," | Confidence: ",DoubleToString(conf*100,1),"%");

   if(!AllowTrading || conf<MinConfidence || signal=="NO_TRADE")
      return;

   // Signal-only by default. Set AllowTrading=true only after independent testing.
   double entry=(signal=="BUY")?tick.ask:tick.bid;
   double sl=(signal=="BUY")?entry-sl_dist:entry+sl_dist;
   double tp1=(signal=="BUY")?entry+sl_dist*TP1_R:entry-sl_dist*TP1_R;
   double tp2=(signal=="BUY")?entry+sl_dist*TP2_R:entry-sl_dist*TP2_R;

   double lots=PositionSize(sl_dist);

   if(PositionSelect(InpSymbol)) return; // one position at a time

   trade.SetDeviationInPoints(30);

   bool ok=false;
   if(signal=="BUY")
      ok=trade.Buy(lots,InpSymbol,0,sl,tp2,"AI Gold BUY");
   else if(signal=="SELL")
      ok=trade.Sell(lots,InpSymbol,0,sl,tp2,"AI Gold SELL");

   if(ok)
      Print("AI trade opened: ",signal," confidence=",DoubleToString(conf,3),
            " entry=",DoubleToString(entry,_Digits),
            " SL=",DoubleToString(sl,_Digits),
            " TP1=",DoubleToString(tp1,_Digits),
            " TP2=",DoubleToString(tp2,_Digits));
}
//+------------------------------------------------------------------+
