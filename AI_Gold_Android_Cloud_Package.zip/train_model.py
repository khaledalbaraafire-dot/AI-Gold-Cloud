# Train the first ML model
#
# CSV must contain OHLCV columns:
# time,open,high,low,close,volume
#
# Example:
# python train_model.py --csv xauusd_m5.csv --out model.joblib

import argparse
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import classification_report, accuracy_score

FEATURES = [
    "ret1", "body", "range", "ema_gap", "trend",
    "buy_sweep", "sell_sweep", "spread_points"
]

def build_features(df):
    df=df.copy()
    df.columns=[c.lower() for c in df.columns]
    df["ema20"]=df.close.ewm(span=20,adjust=False).mean()
    df["ema50"]=df.close.ewm(span=50,adjust=False).mean()
    tr=pd.concat([
        df.high-df.low,
        (df.high-df.close.shift()).abs(),
        (df.low-df.close.shift()).abs()
    ],axis=1).max(axis=1)
    df["atr"]=tr.rolling(14).mean()
    df["ret1"]=(df.close-df.close.shift(1))/df.atr
    df["body"]=(df.close-df.open)/df.atr
    df["range"]=(df.high-df.low)/df.atr
    df["ema_gap"]=(df.close-df.ema50)/df.atr
    df["trend"]=(df.ema20-df.ema50)/df.atr

    prior_high=df.high.shift(1).rolling(20).max()
    prior_low=df.low.shift(1).rolling(20).min()
    df["buy_sweep"]=((df.high>prior_high)&(df.close<prior_high)).astype(float)
    df["sell_sweep"]=((df.low<prior_low)&(df.close>prior_low)).astype(float)

    if "spread_points" not in df:
        df["spread_points"]=0.0

    # Label: whether price moves at least 0.8 ATR upward over next 3 bars.
    future_move=df.close.shift(-3)-df.close
    df["y"]=(future_move > 0.8*df.atr).astype(int)

    return df.dropna()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--csv",required=True)
    ap.add_argument("--out",default="model.joblib")
    args=ap.parse_args()

    df=pd.read_csv(args.csv)
    df=build_features(df)

    # Time-ordered split. Never shuffle financial time series.
    cut=int(len(df)*0.70)
    train=df.iloc[:cut]
    test=df.iloc[cut:]

    model=HistGradientBoostingClassifier(
        max_depth=4, learning_rate=0.05,
        max_iter=250, l2_regularization=1.0,
        random_state=42
    )
    model.fit(train[FEATURES],train.y)

    pred=model.predict(test[FEATURES])
    print("Holdout accuracy:",round(accuracy_score(test.y,pred),4))
    print(classification_report(test.y,pred,digits=4))

    joblib.dump(model,args.out)
    print("Saved:",args.out)
    print("IMPORTANT: accuracy is not trading profit. Test spread, slippage, fees and walk-forward performance.")

if __name__=="__main__":
    main()
